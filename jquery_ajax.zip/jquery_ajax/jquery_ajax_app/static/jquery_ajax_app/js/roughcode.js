export function sayHello() {
    alert('Hello from world');
}



function addNumber(num1, num2) {
    var total = num1 + num2;

    alert(`sum of number is: ${total}`);
}