from django.apps import AppConfig


class JqueryAjaxAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jquery_ajax_app'
